library(testthat)


testthat::test_dir("tests/testthat")