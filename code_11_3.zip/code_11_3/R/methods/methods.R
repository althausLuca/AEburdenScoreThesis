# Define constants for the different methods used in the geheration and analysis
LOG_ANOVA <- "anova"
LM <- "lm"
TWEEDIE <- "tweedie"
QUANTILE_REGRESSION <- "quantile_regression"
WILCOXON <- "wilcoxon"