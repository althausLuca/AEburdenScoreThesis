## Code Execution

If you want to run the code Run the setup.R file to install the required packages The working directory should be set to the folder containing this file (in Rstudio open project and select StatsMA.Rproj). The data folder is too large for overleaf so it is not included in the zip file.
